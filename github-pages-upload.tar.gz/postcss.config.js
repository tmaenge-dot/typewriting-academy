export default {
  plugins: {
    autoprefixer: {}
  }
}